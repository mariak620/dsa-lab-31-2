from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING

from strawberry.types.base import get_object_definition
from strawberry.types.private import is_private

from .exception import StrawberryException
from .utils.source_finder import SourceFinder

if TYPE_CHECKING:
    from strawberry.types.arguments import StrawberryArgument
    from strawberry.types.fields.resolver import StrawberryResolver

    from .exception_source import ExceptionSource


class InvalidArgumentTypeError(StrawberryException):
    def __init__(
        self,
        resolver: StrawberryResolver,
        argument: StrawberryArgument,
    ) -> None:
        from strawberry.types.union import StrawberryUnion

        self.function = resolver.wrapped_func
        self.argument_name = argument.python_name
        # argument_type: Literal["union", "interface"],

        argument_type = "unknown"

        if is_private(argument.type):
            argument_type = "private"
        elif isinstance(argument.type, StrawberryUnion):
            argument_type = "union"
        else:
            type_definition = get_object_definition(argument.type)
            if type_definition and type_definition.is_interface:
                argument_type = "interface"

        self.message = (
            f'Argument "{self.argument_name}" on field '
            f'"{resolver.name}" cannot be of type '
            f'"{argument_type}"'
        )
        self.rich_message = self.message

        if argument_type == "private":
            self.suggestion = (
                "strawberry.Private can only be used on fields. Every resolver "
                "parameter other than self, root, info and strawberry.Parent is a "
                "GraphQL argument."
            )
        elif argument_type == "union":
            self.suggestion = "Unions are not supported as arguments in GraphQL."
        elif argument_type == "interface":
            self.suggestion = "Interfaces are not supported as arguments in GraphQL."
        else:
            self.suggestion = f"{self.argument_name} is not supported as an argument."

        self.annotation_message = (
            f'Argument "{self.argument_name}" cannot be of type "{argument_type}"'
        )

    @cached_property
    def exception_source(self) -> ExceptionSource | None:
        if self.function is None:
            return None  # pragma: no cover

        source_finder = SourceFinder()

        return source_finder.find_argument_from_object(
            self.function,  # type: ignore
            self.argument_name,
        )
