"""Collect fields"""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING, NamedTuple, TypeAlias

from ..language import (
    DirectiveNode,
    FieldNode,
    FragmentDefinitionNode,
    FragmentSpreadNode,
    InlineFragmentNode,
    OperationDefinitionNode,
    SelectionSetNode,
)
from ..pyutils import RefSet
from ..type import (
    GraphQLDeferDirective,
    GraphQLIncludeDirective,
    GraphQLObjectType,
    GraphQLSchema,
    GraphQLSkipDirective,
    is_abstract_type,
)
from ..utilities.type_from_ast import type_from_ast
from .values import (
    FragmentVariableValues,
    VariableValues,
    get_argument_values,
    get_fragment_variable_values,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from .get_variable_signature import GraphQLVariableSignature

__all__ = [
    "CollectFieldsContext",
    "CollectedFields",
    "DeferUsage",
    "FieldDetails",
    "FieldDetailsList",
    "FragmentDetails",
    "GroupedFieldSet",
    "collect_fields",
    "collect_subfields",
    "visit_selection_sets",
]


class DeferUsage(NamedTuple):
    """An optionally labelled linked list of defer usages."""

    directive_node: DirectiveNode
    label: str | None
    parent_defer_usage: DeferUsage | None


class FieldDetails(NamedTuple):
    """A field node with its defer usage and fragment variable values."""

    node: FieldNode
    defer_usage: DeferUsage | None
    fragment_variable_values: FragmentVariableValues | None = None


class FragmentDetails(NamedTuple):
    """A fragment definition with the signatures of its variables."""

    definition: FragmentDefinitionNode
    variable_signatures: dict[str, GraphQLVariableSignature] | None = None


FieldDetailsList: TypeAlias = list[FieldDetails]
GroupedFieldSet: TypeAlias = dict[str, FieldDetailsList]

VisitedFragmentNames: TypeAlias = dict[str, RefSet[DirectiveNode | None]]


class CollectFieldsContext(NamedTuple):
    """Context for collecting fields."""

    schema: GraphQLSchema
    fragments: dict[str, FragmentDetails]
    variable_values: VariableValues
    operation: OperationDefinitionNode
    runtime_type: GraphQLObjectType
    visited_fragment_names: VisitedFragmentNames
    hide_suggestions: bool
    forbidden_directive_instances: list[DirectiveNode]
    forbid_skip_and_include: bool
    on_selection_set: Callable[[SelectionSetNode], None] | None = None


class CollectedFields(NamedTuple):
    """Collected fields with new defer usages."""

    grouped_field_set: GroupedFieldSet
    new_defer_usages: list[DeferUsage]
    forbidden_directive_instances: list[DirectiveNode]


def collect_fields(
    schema: GraphQLSchema,
    fragments: dict[str, FragmentDetails],
    variable_values: VariableValues,
    runtime_type: GraphQLObjectType,
    operation: OperationDefinitionNode,
    hide_suggestions: bool = False,
    forbid_skip_and_include: bool = False,
    on_selection_set: Callable[[SelectionSetNode], None] | None = None,
) -> CollectedFields:
    """Collect fields.

    Given a selection_set, collects all the fields and returns them.

    collect_fields requires the "runtime type" of an object. For a field that
    returns an Interface or Union type, the "runtime type" will be the actual
    object type returned by that field.

    For internal use only.
    """
    grouped_field_set: dict[str, list[FieldDetails]] = defaultdict(list)
    new_defer_usages: list[DeferUsage] = []
    context = CollectFieldsContext(
        schema,
        fragments,
        variable_values,
        operation,
        runtime_type,
        {},
        hide_suggestions,
        [],
        forbid_skip_and_include,
        on_selection_set,
    )

    visit_selection_sets(
        context, operation.selection_set, grouped_field_set, new_defer_usages
    )
    return CollectedFields(
        grouped_field_set, new_defer_usages, context.forbidden_directive_instances
    )


def collect_subfields(
    schema: GraphQLSchema,
    fragments: dict[str, FragmentDetails],
    variable_values: VariableValues,
    operation: OperationDefinitionNode,
    return_type: GraphQLObjectType,
    field_details_list: FieldDetailsList,
    hide_suggestions: bool = False,
) -> CollectedFields:
    """Collect subfields.

    Given a list of field nodes, collects all the subfields of the passed in fields,
    and returns them at the end.

    collect_subfields requires the "return type" of an object. For a field that
    returns an Interface or Union type, the "return type" will be the actual
    object type returned by that field.

    For internal use only.
    """
    context = CollectFieldsContext(
        schema,
        fragments,
        variable_values,
        operation,
        return_type,
        {},
        hide_suggestions,
        [],
        False,
    )
    sub_grouped_field_set: dict[str, list[FieldDetails]] = defaultdict(list)
    new_defer_usages: list[DeferUsage] = []

    for field_detail in field_details_list:
        node = field_detail.node
        if node.selection_set:
            visit_selection_sets(
                context,
                node.selection_set,
                sub_grouped_field_set,
                new_defer_usages,
                field_detail.defer_usage,
                field_detail.fragment_variable_values,
            )

    return CollectedFields(
        sub_grouped_field_set, new_defer_usages, context.forbidden_directive_instances
    )


def visit_selection_sets(
    context: CollectFieldsContext,
    selection_set: SelectionSetNode,
    grouped_field_set: dict[str, list[FieldDetails]],
    new_defer_usages: list[DeferUsage],
    defer_usage: DeferUsage | None = None,
    fragment_variable_values: FragmentVariableValues | None = None,
) -> None:
    """Collect the fields of a selection set and the selection sets it contains.

    For internal use only.
    """
    (
        schema,
        fragments,
        variable_values,
        _operation,
        runtime_type,
        visited_fragment_names,
        hide_suggestions,
        _forbidden_directive_instances,
        _forbid_skip_and_include,
        on_selection_set,
    ) = context

    if on_selection_set:
        on_selection_set(selection_set)

    for selection in selection_set.selections:
        if isinstance(selection, FieldNode):
            if not should_include_node(
                context, selection, variable_values, fragment_variable_values
            ):
                continue
            key = get_field_entry_key(selection)
            grouped_field_set[key].append(
                FieldDetails(selection, defer_usage, fragment_variable_values)
            )
        elif isinstance(selection, InlineFragmentNode):
            if not should_include_node(
                context, selection, variable_values, fragment_variable_values
            ) or not does_fragment_condition_match(schema, selection, runtime_type):
                continue

            new_defer_usage = get_defer_usage(
                variable_values,
                fragment_variable_values,
                selection,
                defer_usage,
            )

            if new_defer_usage is None:
                visit_selection_sets(
                    context,
                    selection.selection_set,
                    grouped_field_set,
                    new_defer_usages,
                    defer_usage,
                    fragment_variable_values,
                )
            else:
                new_defer_usages.append(new_defer_usage)
                visit_selection_sets(
                    context,
                    selection.selection_set,
                    grouped_field_set,
                    new_defer_usages,
                    new_defer_usage,
                    fragment_variable_values,
                )
        elif isinstance(selection, FragmentSpreadNode):  # pragma: no branch
            frag_name = selection.name.value

            if not should_include_node(
                context, selection, variable_values, fragment_variable_values
            ):
                continue

            fragment = fragments.get(frag_name)
            if fragment is None or not does_fragment_condition_match(
                schema, fragment.definition, runtime_type
            ):
                continue

            new_defer_usage = get_defer_usage(
                variable_values,
                fragment_variable_values,
                selection,
                defer_usage,
            )

            maybe_new_defer_usage = (
                defer_usage if new_defer_usage is None else new_defer_usage
            )
            visited_defer_set = visited_fragment_names.get(frag_name)
            if visited_defer_set is None:
                visited_defer_set = visited_fragment_names[frag_name] = RefSet()

            if None in visited_defer_set or (
                maybe_new_defer_usage is not None
                and maybe_new_defer_usage.directive_node in visited_defer_set
            ):
                continue

            if new_defer_usage is not None:
                new_defer_usages.append(new_defer_usage)

            visited_defer_set.add(
                None
                if maybe_new_defer_usage is None
                else maybe_new_defer_usage.directive_node
            )

            fragment_variable_signatures = fragment.variable_signatures
            new_fragment_variable_values: FragmentVariableValues | None = None
            if fragment_variable_signatures:
                new_fragment_variable_values = get_fragment_variable_values(
                    selection,
                    fragment_variable_signatures,
                    variable_values,
                    fragment_variable_values,
                    hide_suggestions,
                )

            visit_selection_sets(
                context,
                fragment.definition.selection_set,
                grouped_field_set,
                new_defer_usages,
                maybe_new_defer_usage,
                new_fragment_variable_values,
            )


def get_defer_usage(
    variable_values: VariableValues,
    fragment_variable_values: FragmentVariableValues | None,
    node: FragmentSpreadNode | InlineFragmentNode,
    parent_defer_usage: DeferUsage | None,
) -> DeferUsage | None:
    """Get values of defer directive if active.

    Returns an object containing the `@defer` arguments if a field should be
    deferred based on the experimental flag, defer directive present and
    not disabled by the "if" argument.
    """
    defer_name = GraphQLDeferDirective.name
    directive_node = next(
        (
            directive
            for directive in node.directives or ()
            if directive.name.value == defer_name
        ),
        None,
    )

    if directive_node is None:
        return None

    defer = get_argument_values(
        GraphQLDeferDirective,
        directive_node,
        variable_values,
        fragment_variable_values,
    )

    if defer.get("if") is False:
        return None

    return DeferUsage(directive_node, defer.get("label"), parent_defer_usage)


def should_include_node(
    context: CollectFieldsContext,
    node: FragmentSpreadNode | FieldNode | InlineFragmentNode,
    variable_values: VariableValues,
    fragment_variable_values: FragmentVariableValues | None = None,
) -> bool:
    """Check if node should be included

    Determines if a field should be included based on the @include and @skip
    directives, where @skip has higher precedence than @include.
    """
    skip_directive_node = (
        next(
            (
                directive
                for directive in node.directives
                if directive.name.value == GraphQLSkipDirective.name
            ),
            None,
        )
        if node.directives
        else None
    )
    if skip_directive_node and context.forbid_skip_and_include:
        context.forbidden_directive_instances.append(skip_directive_node)
        return False
    skip = (
        get_argument_values(
            GraphQLSkipDirective,
            skip_directive_node,
            variable_values,
            fragment_variable_values,
            context.hide_suggestions,
        )
        if skip_directive_node
        else None
    )
    if skip and skip["if"]:
        return False

    include_directive_node = (
        next(
            (
                directive
                for directive in node.directives
                if directive.name.value == GraphQLIncludeDirective.name
            ),
            None,
        )
        if node.directives
        else None
    )
    if include_directive_node and context.forbid_skip_and_include:
        context.forbidden_directive_instances.append(include_directive_node)
        return False
    include = (
        get_argument_values(
            GraphQLIncludeDirective,
            include_directive_node,
            variable_values,
            fragment_variable_values,
            context.hide_suggestions,
        )
        if include_directive_node
        else None
    )
    return not (include and not include["if"])


def does_fragment_condition_match(
    schema: GraphQLSchema,
    fragment: FragmentDefinitionNode | InlineFragmentNode,
    type_: GraphQLObjectType,
) -> bool:
    """Determine if a fragment is applicable to the given type.

    :meta private:
    """
    type_condition_node = fragment.type_condition
    if not type_condition_node:
        return True
    conditional_type = type_from_ast(schema, type_condition_node)
    if conditional_type is type_:
        return True
    if is_abstract_type(conditional_type):
        return schema.is_sub_type(conditional_type, type_)
    return False


def get_field_entry_key(node: FieldNode) -> str:
    """Implement the logic to compute the key of a given field's entry.

    :meta private:
    """
    return node.alias.value if node.alias else node.name.value
