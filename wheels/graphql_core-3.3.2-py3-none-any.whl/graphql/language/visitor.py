"""AST Visitor"""

from __future__ import annotations

from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    NamedTuple,
    TypeAlias,
)

from ..pyutils import inspect, snake_to_camel
from . import ast
from .ast import QUERY_DOCUMENT_KEYS, Node

if TYPE_CHECKING:
    from collections.abc import Callable, Collection

__all__ = [
    "BREAK",
    "IDLE",
    "REMOVE",
    "SKIP",
    "ParallelVisitor",
    "Visitor",
    "VisitorAction",
    "VisitorKeyMap",
    "visit",
]


class VisitorActionEnum(Enum):
    """Special return values for the visitor methods.

    You can also use the values of this enum directly.
    """

    BREAK = True
    SKIP = False
    REMOVE = Ellipsis


VisitorAction: TypeAlias = VisitorActionEnum | None

# Note that in GraphQL.js these are defined *differently*:
# BREAK = {}, SKIP = false, REMOVE = null, IDLE = undefined

BREAK = VisitorActionEnum.BREAK
SKIP = VisitorActionEnum.SKIP
REMOVE = VisitorActionEnum.REMOVE
IDLE = None

VisitorKeyMap: TypeAlias = dict[str, tuple[str, ...]]


class EnterLeaveVisitor(NamedTuple):
    """Visitor with functions for entering and leaving."""

    enter: Callable[..., VisitorAction | None] | None
    leave: Callable[..., VisitorAction | None] | None


class Visitor:
    """Visitor that walks through an AST.

    Visitors can define two generic methods "enter" and "leave". The former will be
    called when a node is entered in the traversal, the latter is called after visiting
    the node and its child nodes. These methods have the following signature::

        def enter(self, node, key, parent, path, ancestors):
            # The return value has the following meaning:
            # IDLE (None): no action
            # SKIP: skip visiting this node
            # BREAK: stop visiting altogether
            # REMOVE: delete this node
            # any other value: replace this node with the returned value
            return

        def leave(self, node, key, parent, path, ancestors):
            # The return value has the following meaning:
            # IDLE (None) or SKIP: no action
            # BREAK: stop visiting altogether
            # REMOVE: delete this node
            # any other value: replace this node with the returned value
            return

    The parameters have the following meaning:

    :arg node: Current node being visited.
    :arg key: Index or key for this node within the parent node or array.
    :arg parent: Parent immediately above this node, which may be an array.
    :arg path: Key path from the root node to this node.
    :arg ancestors: All nodes and arrays visited before reaching this node's parent.
        These correspond to array indices in ``path``.
        Note: ancestors includes arrays that contain the visited node's parent.

    You can also define node kind specific methods by suffixing them with an underscore
    followed by the kind of the node to be visited. For instance, to visit ``field``
    nodes, you would define the methods ``enter_field()`` and/or ``leave_field()``,
    with the same signature as above. If no kind specific method has been defined
    for a given node, the generic method is called.

    A visitor can provide separate enter and leave methods for nodes of a kind:

    >>> from graphql import parse, visit, Visitor
    >>> document = parse('{ hero { name } }')
    >>> events = []
    >>> class FieldVisitor(Visitor):
    ...     def enter_field(self, node, *_args):
    ...         events.append(f'enter:{node.name.value}')
    ...     def leave_field(self, node, *_args):
    ...         events.append(f'leave:{node.name.value}')
    >>> visit(document, FieldVisitor()) is document
    True
    >>> events
    ['enter:hero', 'enter:name', 'leave:name', 'leave:hero']
    """

    # Provide special return values as attributes
    BREAK, SKIP, REMOVE, IDLE = BREAK, SKIP, REMOVE, IDLE

    enter_leave_map: dict[str, EnterLeaveVisitor]
    """Cache of the enter and leave methods of this visitor per node kind."""

    def __init_subclass__(cls) -> None:
        """Verify that all defined handlers are valid."""
        super().__init_subclass__()
        for attr in cls.__dict__:
            if attr.startswith("_"):
                continue
            attr_kind = attr.split("_", 1)
            if len(attr_kind) < 2:
                kind: str | None = None
            else:
                attr, kind = attr_kind  # noqa: PLW2901
            if attr in ("enter", "leave") and kind:
                name = snake_to_camel(kind) + "Node"
                node_cls = getattr(ast, name, None)
                if (
                    not node_cls
                    or not isinstance(node_cls, type)
                    or not issubclass(node_cls, Node)
                ):
                    msg = f"Invalid AST node kind: {kind}."
                    raise TypeError(msg)

    def __init__(self) -> None:
        self.enter_leave_map = {}

    def get_enter_leave_for_kind(self, kind: str) -> EnterLeaveVisitor:
        """Given a node kind, return the EnterLeaveVisitor for that kind.

        :param kind: The AST node kind to resolve methods for.
        :returns: The enter and leave methods that apply for the given node kind.

        >>> from graphql import Visitor
        >>> class FieldVisitor(Visitor):
        ...     def enter_field(self, node, *_args):
        ...         pass
        >>> enter, leave = FieldVisitor().get_enter_leave_for_kind('field')
        >>> callable(enter)
        True
        >>> leave is None
        True
        """
        try:
            return self.enter_leave_map[kind]
        except KeyError:
            enter_fn = getattr(self, f"enter_{kind}", None)
            if not enter_fn:
                enter_fn = getattr(self, "enter", None)
            leave_fn = getattr(self, f"leave_{kind}", None)
            if not leave_fn:
                leave_fn = getattr(self, "leave", None)
            enter_leave = EnterLeaveVisitor(enter_fn, leave_fn)
            self.enter_leave_map[kind] = enter_leave
            return enter_leave


def visit(
    root: Node, visitor: Visitor, visitor_keys: VisitorKeyMap | None = None
) -> Any:
    r"""Visit each node in an AST.

    :func:`~.visit` will walk through an AST using a depth-first traversal, calling the
    visitor's enter methods at each node in the traversal, and calling the leave methods
    after visiting that node and all of its child nodes.

    By returning different values from the enter and leave methods, the behavior of the
    visitor can be altered, including skipping over a sub-tree of the AST (by returning
    False), editing the AST by returning a value or None to remove the value, or to stop
    the whole traversal by returning :data:`~.BREAK`.

    When using :func:`~.visit` to edit an AST, the original AST will not be modified,
    and a new version of the AST with the changes applied will be returned from the
    visit function.

    To customize the node attributes to be used for traversal, you can provide a
    dictionary visitor_keys mapping node kinds to node attributes.

    :param root: The AST node at which to start traversal.
    :param visitor: The visitor whose methods are called while traversing.
    :param visitor_keys: Optional map of child keys to visit for each AST node kind.
    :returns: The original AST, an edited AST, or a reduced value depending on the
        visitor.

    Return values control traversal: ``None`` makes no change, ``SKIP`` or ``False``
    skips a subtree, ``BREAK`` or ``True`` stops traversal, ``REMOVE`` or ``...``
    removes a node, and any other value replaces the current node:

    >>> from dataclasses import replace
    >>> from graphql import NameNode, parse, print_ast, visit, Visitor
    >>> document = parse('{ hero { name } }')
    >>> class RenameVisitor(Visitor):
    ...     def enter_field(self, node, *_args):
    ...         if node.name.value == 'hero':
    ...             return replace(node, name=NameNode(value='human'))
    >>> edited_ast = visit(document, RenameVisitor())
    >>> print_ast(edited_ast)
    '{\n  human {\n    name\n  }\n}'

    A kind specific visitor method runs when entering nodes of that kind:

    >>> field_names = []
    >>> class FieldVisitor(Visitor):
    ...     def enter_field(self, node, *_args):
    ...         field_names.append(node.name.value)
    >>> visit(document, FieldVisitor()) is document
    True
    >>> field_names
    ['hero', 'name']

    Generic enter and leave methods run for every node:

    >>> class CountingVisitor(Visitor):
    ...     entered = left = 0
    ...     def enter(self, *_args):
    ...         self.entered += 1
    ...     def leave(self, *_args):
    ...         self.left += 1
    >>> visitor = CountingVisitor()
    >>> visit(document, visitor) is document
    True
    >>> visitor.entered == visitor.left
    True
    >>> visitor.entered > 0
    True

    A visitor can return values from its leave methods to build a reduced result
    instead of returning an edited AST:

    >>> class ReducingVisitor(Visitor):
    ...     def leave_name(self, node, *_args):
    ...         return node.value
    ...     def leave_field(self, node, *_args):
    ...         if node.selection_set is None:
    ...             return node.name
    ...         return f'{node.name} {{ {node.selection_set} }}'
    ...     def leave_selection_set(self, node, *_args):
    ...         return ' '.join(node.selections)
    ...     def leave_operation_definition(self, node, *_args):
    ...         return node.selection_set
    ...     def leave_document(self, node, *_args):
    ...         return '\n'.join(node.definitions)
    >>> visit(document, ReducingVisitor())
    'hero { name }'
    """
    if not isinstance(root, Node):
        msg = f"Not an AST Node: {inspect(root)}."
        raise TypeError(msg)
    if not isinstance(visitor, Visitor):
        msg = f"Not an AST Visitor: {inspect(visitor)}."
        raise TypeError(msg)
    if visitor_keys is None:
        visitor_keys = QUERY_DOCUMENT_KEYS

    stack: Any = None
    in_array = False
    keys: tuple[Node, ...] = (root,)
    idx = -1
    edits: list[Any] | None = None
    node: Any = root
    key: Any = None
    parent: Any = None
    path: list[Any] = []
    path_append = path.append
    path_pop = path.pop
    ancestors: list[Any] = []
    ancestors_append = ancestors.append
    ancestors_pop = ancestors.pop

    while True:
        idx += 1
        is_leaving = idx == len(keys)
        if is_leaving:
            is_edited = edits
            node_is_array = in_array
            key = path[-1] if ancestors else None
            node = parent
            parent = ancestors_pop() if ancestors else None
            if edits:
                if in_array:
                    node = list(node)
                    edit_offset = 0
                    for edit_key, edit_value in edits:
                        array_key = edit_key - edit_offset
                        if edit_value is REMOVE or edit_value is Ellipsis:
                            node.pop(array_key)
                            edit_offset += 1
                        else:
                            node[array_key] = edit_value
                    node = tuple(node)
                else:
                    # Create new node with edited values (immutable-friendly)
                    values = {k: getattr(node, k) for k in node.keys} | dict(edits)
                    node = node.__class__(**values)
                    node_is_array = isinstance(node, tuple)
            in_array, idx, keys, edits, stack = stack
        else:
            if parent:
                if in_array:
                    key = idx
                    node = parent[key]
                else:
                    key = keys[idx]
                    node = getattr(parent, key, None)
                if node is None:
                    continue
                path_append(key)
            node_is_array = isinstance(node, tuple)

        if node_is_array:
            result = None
        else:
            if not isinstance(node, Node):
                msg = f"Invalid AST Node: {inspect(node)}."
                raise TypeError(msg)
            enter_leave = visitor.get_enter_leave_for_kind(node.kind)
            visit_fn = enter_leave.leave if is_leaving else enter_leave.enter
            if visit_fn:
                result = visit_fn(node, key, parent, path, ancestors)

                if result is not None:
                    if result is BREAK or result is True:
                        break

                    if result is SKIP or result is False:
                        if not is_leaving:
                            path_pop()
                            continue

                    else:
                        if edits is None:
                            edits = []
                        edits.append((key, result))
                        if not is_leaving:
                            if isinstance(result, Node):
                                node = result
                                node_is_array = isinstance(node, tuple)
                            else:
                                path_pop()
                                continue
            else:
                result = None

        if is_leaving:
            if result is None and is_edited:
                if edits is None:
                    edits = []
                edits.append((key, node))
            if path:
                path_pop()
        else:
            # stack entry fields: (in_array, idx, keys, edits, prev)
            stack = (in_array, idx, keys, edits, stack)
            in_array = node_is_array
            keys = node if in_array else visitor_keys.get(node.kind, ())  # type: ignore
            idx = -1
            edits = None
            if parent:
                ancestors_append(parent)
            parent = node

        if not stack:
            break

    if edits:
        return edits[-1][1]

    return root


class ParallelVisitor(Visitor):
    """A Visitor which delegates to many visitors to run in parallel.

    Each visitor will be visited for each node before moving on.

    If a prior visitor edits a node, no following visitors will see that node.

    :param visitors: The visitors to merge into one parallel visitor.

    >>> from graphql import parse, visit, ParallelVisitor, Visitor
    >>> document = parse('{ hero { name } }')
    >>> events = []
    >>> class FieldVisitor(Visitor):
    ...     def enter_field(self, node, *_args):
    ...         events.append(f'field:{node.name.value}')
    >>> class NameVisitor(Visitor):
    ...     def enter_name(self, node, *_args):
    ...         events.append(f'name:{node.value}')
    >>> parallel_visitor = ParallelVisitor([FieldVisitor(), NameVisitor()])
    >>> visit(document, parallel_visitor) is document
    True
    >>> events
    ['field:hero', 'name:hero', 'field:name', 'name:name']
    """

    def __init__(self, visitors: Collection[Visitor]) -> None:
        """Create a new visitor from the given list of parallel visitors."""
        super().__init__()
        self.visitors = visitors
        self.skipping: list[Any] = [None] * len(visitors)

    def get_enter_leave_for_kind(self, kind: str) -> EnterLeaveVisitor:
        """Given a node kind, return the EnterLeaveVisitor for that kind.

        The returned methods delegate to the corresponding methods of all visitors.

        :param kind: The AST node kind to resolve methods for.
        :returns: The merged enter and leave methods for the given node kind.

        >>> from graphql import ParallelVisitor, Visitor
        >>> class FieldVisitor(Visitor):
        ...     def enter_field(self, node, *_args):
        ...         pass
        >>> class NameVisitor(Visitor):
        ...     def leave_name(self, node, *_args):
        ...         pass
        >>> visitor = ParallelVisitor([FieldVisitor(), NameVisitor()])
        >>> enter, leave = visitor.get_enter_leave_for_kind('field')
        >>> callable(enter) and callable(leave)
        True
        >>> visitor.get_enter_leave_for_kind('document')
        EnterLeaveVisitor(enter=None, leave=None)
        """
        try:
            return self.enter_leave_map[kind]
        except KeyError:
            has_visitor = False
            enter_list: list[
                tuple[int, Callable[..., VisitorAction | None] | None]
            ] = []
            leave_list: list[
                tuple[int, Callable[..., VisitorAction | None] | None]
            ] = []
            for i, visitor in enumerate(self.visitors):
                enter, leave = visitor.get_enter_leave_for_kind(kind)
                if not has_visitor and (enter or leave):
                    has_visitor = True
                enter_list.append((i, enter))
                leave_list.append((i, leave))

            enter_pairs = tuple(enter_list)
            leave_pairs = tuple(leave_list)

            if has_visitor:

                def enter(node: Node, *args: Any) -> VisitorAction | None:
                    skipping = self.skipping
                    args = (node, *args)
                    for i, fn in enter_pairs:
                        if not skipping[i] and fn:
                            result = fn(*args)
                            if result is None:
                                continue
                            if result is SKIP or result is False:
                                skipping[i] = node
                            elif result is BREAK or result is True:
                                skipping[i] = BREAK
                            else:
                                return result
                    return None

                def leave(node: Node, *args: Any) -> VisitorAction | None:
                    skipping = self.skipping
                    args = (node, *args)
                    for i, fn in leave_pairs:
                        if not skipping[i]:
                            if fn:
                                result = fn(*args)
                                if result is None:
                                    continue
                                if result is BREAK or result is True:
                                    skipping[i] = BREAK
                                elif result is not SKIP and result is not False:
                                    return result
                        elif skipping[i] is node:
                            skipping[i] = None
                    return None

            else:
                enter = leave = None

            enter_leave = EnterLeaveVisitor(enter, leave)
            self.enter_leave_map[kind] = enter_leave
            return enter_leave
