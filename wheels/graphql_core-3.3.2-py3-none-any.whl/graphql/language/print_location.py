"""Print location in GraphQL source"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, cast

from .location import SourceLocation, get_location

if TYPE_CHECKING:
    from .ast import Location
    from .source import Source

__all__ = ["print_location", "print_source_location"]


def print_location(location: Location) -> str:
    r"""Render a helpful description of the location in the GraphQL Source document.

    :param location: The AST location to print.
    :returns: A formatted source excerpt with line and column information.

    >>> from graphql.language import parse, print_location
    >>> document = parse('type Query { hello: String }')
    >>> print_location(document.definitions[0].loc)
    'GraphQL request:1:1\n1 | type Query { hello: String }\n  | ^'
    """
    return print_source_location(
        location.source, get_location(location.source, location.start)
    )


_re_newline = re.compile(r"\r\n|[\n\r]")


def print_source_location(source: Source, source_location: SourceLocation) -> str:
    r"""Render a helpful description of the location in the GraphQL Source document.

    :param source: The source document that contains the location.
    :param source_location: The 1-indexed line and column to print.
    :returns: A formatted source excerpt with line and column information.

    >>> from graphql.language import (
    ...     Source, SourceLocation, print_source_location)
    >>> source = Source('type Query { hello: String }')
    >>> print_source_location(source, SourceLocation(line=1, column=14))
    'GraphQL request:1:14\n1 | type Query { hello: String }\n  |              ^'
    """
    first_line_column_offset = source.location_offset.column - 1
    body = "".rjust(first_line_column_offset) + source.body

    line_index = source_location.line - 1
    line_offset = source.location_offset.line - 1
    line_num = source_location.line + line_offset

    column_offset = first_line_column_offset if source_location.line == 1 else 0
    column_num = source_location.column + column_offset
    location_str = f"{source.name}:{line_num}:{column_num}\n"

    lines = _re_newline.split(body)  # works a bit different from splitlines()
    location_line = lines[line_index]

    # Special case for minified documents
    if len(location_line) > 120:
        sub_lines = [
            location_line[i : i + 80] for i in range(0, len(location_line), 80)
        ]

        # At EOF, point just after the last character, even in a full chunk.
        zero_based_column = column_num - 1
        sub_line_index = min(zero_based_column // 80, len(sub_lines) - 1)
        sub_line_column_num = column_num - sub_line_index * 80

        return location_str + print_prefixed_lines(
            (f"{line_num} |", sub_lines[0]),
            *[("|", sub_line) for sub_line in sub_lines[1 : sub_line_index + 1]],
            ("|", "^".rjust(sub_line_column_num)),
            (
                "|",
                sub_lines[sub_line_index + 1]
                if sub_line_index < len(sub_lines) - 1
                else None,
            ),
        )

    return location_str + print_prefixed_lines(
        (f"{line_num - 1} |", lines[line_index - 1] if line_index > 0 else None),
        (f"{line_num} |", location_line),
        ("|", "^".rjust(column_num)),
        (
            f"{line_num + 1} |",
            lines[line_index + 1] if line_index < len(lines) - 1 else None,
        ),
    )


def print_prefixed_lines(*lines: tuple[str, str | None]) -> str:
    """Print lines specified like this: ("prefix", "string")"""
    existing_lines = [
        cast("tuple[str, str]", line) for line in lines if line[1] is not None
    ]
    pad_len = max(len(line[0]) for line in existing_lines)
    return "\n".join(
        prefix.rjust(pad_len) + (" " + line if line else "")
        for prefix, line in existing_lines
    )
